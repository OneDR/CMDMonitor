#!/usr/bin
mono CMDMonitor/bin/debug/CMDSecure.exe
